import HomeController from './HomeController'
import SitemapController from './SitemapController'
import PdfToAudioController from './PdfToAudioController'
import Settings from './Settings'
const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
SitemapController: Object.assign(SitemapController, SitemapController),
PdfToAudioController: Object.assign(PdfToAudioController, PdfToAudioController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers