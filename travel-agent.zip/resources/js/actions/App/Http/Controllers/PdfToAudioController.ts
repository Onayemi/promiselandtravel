import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pdf-to-audio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PdfToAudioController::index
 * @see app/Http/Controllers/PdfToAudioController.php:15
 * @route '/pdf-to-audio'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PdfToAudioController::convert
 * @see app/Http/Controllers/PdfToAudioController.php:35
 * @route '/pdf-to-audio/convert'
 */
export const convert = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: convert.url(options),
    method: 'post',
})

convert.definition = {
    methods: ["post"],
    url: '/pdf-to-audio/convert',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PdfToAudioController::convert
 * @see app/Http/Controllers/PdfToAudioController.php:35
 * @route '/pdf-to-audio/convert'
 */
convert.url = (options?: RouteQueryOptions) => {
    return convert.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfToAudioController::convert
 * @see app/Http/Controllers/PdfToAudioController.php:35
 * @route '/pdf-to-audio/convert'
 */
convert.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: convert.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PdfToAudioController::convert
 * @see app/Http/Controllers/PdfToAudioController.php:35
 * @route '/pdf-to-audio/convert'
 */
    const convertForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: convert.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PdfToAudioController::convert
 * @see app/Http/Controllers/PdfToAudioController.php:35
 * @route '/pdf-to-audio/convert'
 */
        convertForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: convert.url(options),
            method: 'post',
        })
    
    convert.form = convertForm
const PdfToAudioController = { index, convert }

export default PdfToAudioController